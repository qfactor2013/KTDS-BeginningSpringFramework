package myspring.user.dao;

public @interface MyMapper {
}
